var app = angular.module('calculator',[]);

app.controller("calculatorBasic",function($scope) {
	
	$scope.firstNum = "";
	$scope.secondNum = "";
	$scope.operator = "";
	$scope.calcDisplay = "";
	var displayOperator = false;
	var displaySecondNum = false;
	
	$scope.clearNumbers = clearCalculator;
	
	function clearCalculator() {
		displaySecondNum = false;
		displayOperator = false;
		$scope.firstNum = '';
       $scope.secondNum = '';
       $scope.operator = '';
       $scope.result = '';
       $scope.calcDisplay = '';
	}
	
	$scope.showNumber = showNumbersInCal;
	
	function showNumbersInCal(num) {
		if($scope.firstNum.length <= 30 && $scope.secondNum.length <= 30){
	        if(displaySecondNum) {
	            $scope.secondNum += num;
	        } else {
	            $scope.firstNum += num;
	            displayOperator = true;
	        }
		}
   }

	function displaySecondNumber() {
		displaySecondNum = true;
	}
	
	$scope.showOperator = showOperatorInCal;
	   
	function showOperatorInCal(operator) {
		if(displayOperator){		
	        $scope.operator = operator;
	        displaySecondNumber();
		}
	}

	$scope.calculatorOperation = calculatorOperation;
	
	function calculatorOperation() {
	       if($scope.firstNum != '' && $scope.secondNum != '') {
	            var calculatorResult = eval($scope.firstNum) + $scope.operator + eval($scope.secondNum);
	            $scope.result = eval(calculatorResult);
	       }
	}	
});